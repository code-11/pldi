Elizabeth Mahon
Brendan Ritter

elizabeth.mahon@students.olin.edu
brendan.ritter@students.olin.edu

We had to move some of the function around in the evaluator in order to make things compile right.
Also, I don't think we can make multidimensional lists with the type of cons we were supposed to implement, but it wasn't one of the test cases so...

