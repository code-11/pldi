Elizabeth Mahon and Brendan Ritter
elizabeth.mahon@students.olin.edu
brendan.ritter@students.olin.edu

If you declare a local variable with "nothing else"
ie var y=10 or {var y=10; print(y); var y=20}
it makes an empty I.SBlock. This situation was not in the test cases, very sneaky.


